#' GWbudget: Package to calculate the Groundwater Budget using different methodologies
#'
#' @section calibration functions:
#'  The calibration functions includes functions to calibrate, calculate model fit, and objective
#'  functions.
#'
#'  The functions in this section are:
#'
#'  sum_squared_residuals, mean_average_deviation, nash_sutcliffe, log_nash_sutcliffe,
#'  mass_balance_error, calibrate, uncertainty_quantification
#'
#' @section digital_filter functions:
#'  The digital_filter functions include functions to calculate the baseflow from a discharge
#'  time series using different digital filters.
#'
#'  The functions in this section are:
#'
#'  nathan_filter, chapman_filter, eckhardt_filter
#'
#' @section graphical functions:
#'  The graphical functions include functions used to separate the baseflow from a discharge
#'  time series using simple graphical methods.
#'
#'  The function in this section is:
#'
#'  baseflow_graphical1
#'
#' @section abcd_model functions:
#'  The abcd_model functions includes the annual and monthly version of the abcd model.
#'
#'  The functions in this section are:
#'
#'  abcd.year.model, abcd.month.model, abcd.mod.year.model, abcd.mod.month.model
#'
#'
#' @docType package
#' @name GWbudget
NULL
#' @title
#' nathan_filter
#' @description
#' Function to calculate the baseflow from a discharge time series using the digital filter
#' proposed by Nathan1991.
#' @param Q A numeric vector with the discharge time series
#' @param a A numeric value specifying the filter parameter
#' @return
#' A numeric vector with the calculated baseflow
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family digital_filter functions
#' @source Nathan, R. and McMahon, T. 1991. Evaluation of automated techniques for base flow
#' and recession analyses, Water Resources Research, 27, 1783-1784
nathan_filter <- function(Q, a){
  nq <- length(Q)
  Qbf <- vector('numeric', length = nq)
  Qbf[1] <- 0.5*Q[1]
  for(it in 2:nq){
    Qbf[it] <- a*Q[it-1]+0.5*(1-a)*(Q[it]+Q[it-1])
    if(Qbf[it] > Q[it]){
      Qbf[it] <- Q[it]
    }
  }
  return(Qbf)
}
#' @title
#' chapman_filter
#' @description
#' Function to calculate the baseflow from a discharge time series using the digital filter
#' proposed by Chapman1990.
#' @param Q A numeric vector with the discharge time series
#' @param a A numeric value specifying the filter parameter
#' @return
#' A numeric vector with the calculated baseflow
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family digital_filter functions
#' @source Chapman, T. G. 1991. Comment on "Evaluation of automated techniques for base flow
#' and recession analyses" by R. J. Nathan and T. A. McMahon, Water Resources Research, 27,
#' 1783-1784
chapman_filter <- function(Q, a){
  nq <- length(Q)
  Qbf <- vector('numeric', length = nq)
  Qbf[1] <- 0.5*Q[1]
  coef1 <- (3*a-1)/(3-a)
  coef2 <- (1-a)/(3-a)
  for(it in 2:nq){
    Qbf[it] <- coef1*Qbf[it-1] + coef2*(Q[it]+Q[it-1])
    #Qbf[it] <- (a/(2-a))*Qbf[it-1]+((1-a)/(2-a))*Q[it]
    if(Qbf[it] > Q[it]){
      Qbf[it] <- Q[it]
    }
  }
  return(Qbf)
}
#' @title
#' eckhardt_filter
#' @description
#' Function to calculate the baseflow from a discharge time series using the digital filter
#' proposed by Eckhardt2005.
#' @param Q A numeric vector with the discharge time series
#' @param a A numeric value specifying the filter parameter
#' @param BFImax A numeric value specifying the maximum Base Flow Index used in the separation.
#' @return
#' A numeric vector with the calculated baseflow
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family digital_filter functions
#' @source Eckhardt, K.,  2005. How to construct recursive digital filters for baseflow
#' separation, Hydrological Processes, 19, 507-515
eckhardt_filter <- function(Q, a, BFImax){
  nq <- length(Q)
  Qbf <- vector('numeric', length = nq)
  Qbf[1] <- 0.5*Q[1]
  coef1 <- (1-BFImax)*a
  coef2 <- (1-a)*BFImax
  coef3 <- (1-a*BFImax)
  for(it in 2:nq){
    Qbf[it] <- (coef1*Qbf[it-1]+coef2*Q[it])/coef3
    if(Qbf[it] > Q[it]){
      Qbf[it] <- Q[it]
    }
  }
  return(Qbf)
}
#' @title
#' baseflow_graphical1
#' @description
#' Function to calculate the baseflow from a discharge time series using the graphical approach
#' @param Q A numeric vector with the discharge time series
#' @return
#' A list with the following entries:
#' \itemize{
#' \item t: numeric vector with the time
#' \item Qbf: numeric vector with the calculated baseflow
#' }
#' @importFrom pracma interp1
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family graphical functions
baseflow_graphical1 <- function(Q){
  if(class(Q) != 'numeric'){
    stop('A numeric vector is required as input')
  }
  dQs <- diff(Q)
  Qsmin <- vector('numeric', length=length(dQs))
  tmin <- vector('numeric', length=length(dQs))
  Qsmin[1:2] <- min(Q[1:2])
  pos <- 0
  for(i in 2:length(dQs)){
    p1 <- dQs[i-1]
    p2 <- dQs[i]
    #p3 <- dQs[i+1]
    if(p1 < 0.0 & p2 > 0.0){
      pos <- pos + 1
      Qsmin[pos] <- Q[i]
      tmin[pos] <- i
    }
  }
  #
  #print(tmin[1:pos])
  #print(Qsmin[1:pos])
  nt <- pos
  rt <- range(tmin[1:pos])
  bf <- interp1(tmin[1:nt],Qsmin[1:nt],rt[1]:rt[2])
  bf1 <- c(rep(bf[1],tmin[1]), bf, rep(bf[pos],length(Q)-rt[2]-1))
  #print(bf1)
  #bf1 <- c(bf[1],bf[1],bf,bf[222],bf[222],bf[222],bf[222])
  #
  res <- list(t = 1:length(Q), Qbf = bf1)
  return(res)
}
#' @title
#' abcd.year.model
#' @description
#' Function to calculate the components of the hydrological cycle using the abcd model on a yearly basis
#' @param par.model A numeric vector of length 5 with the values of the abcd parameters and the initial groundwater storage
#' @param Prec A numeric vector with the values of the Precipitation (on a yearly basis)
#' @param ... Additional parameters (used for compatibility reasons)
#' @return
#' A list with the following elements:
#' \itemize{
#' \item Qt: Numeric vector with the yearly discharges
#' \item SRt: Numeric vector with the surface runnoff
#' \item ETt: Numeric vector with the actual evapotranspiration
#' \item Dt: Numeric vector with the deep percolation
#' \item BFt: Numeric vector with the base flow
#' \item GFt: Numeric vector with the groundwater flow in the aquifer
#' \item GSt: Numeric vector with the groundwater storage
#' }
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family abcd_model functions
abcd.year.model <- function(par.model = c(0,0,0,0,0), Prec, ...){
  #
  a <- par.model[1]
  b <- par.model[2]
  c <- par.model[3]
  d <- par.model[4]
  # Initial GW storage
  G_1 <- par.model[5]
  # Initialize output vectors
  number_years <- length(Prec)
  GS <- vector('numeric', length = number_years)
  BF <- vector('numeric', length = number_years)
  Qs <- vector('numeric', length = number_years)
  GF <- vector('numeric', length = number_years)
  #
  #Surface runnof
  SR <- a*Prec
  In <- (1.0-a)*Prec
  #Evapotranspiration
  E <- b*In
  # Deep percolation
  DP <- (1.0-b)*In
  #Base flow
  BF[1] <- c*G_1
  # GW Flow
  GF[1] <- d*G_1
  for(it in 1:length(Prec)){
    if(it == 1){
      BF[it] <- c*G_1
      GF[it] <- d*G_1
      GS[it] <- (G_1-BF[it]-GF[it])+DP[it]
    }
    else {
      BF[it] <- c*GS[it-1]
      GF[it] <- d*GS[it-1]
      GS[it] <- (GS[it-1]-BF[it]-GF[it])+DP[it]
    }
    Qs[it] <- SR[it] + BF[it]
  }
  #res <- Qs
  res <- list(Qt = Qs, SRt = SR, ETt = E, Dt = DP, BFt = BF, GSt = GS, GFt = GF)
  return(res)
}
#' @title
#' abcd.month.model
#' @description
#' Function to calculate the components of the hydrological cycle using the abcd model on a monthly basis
#' @param par.model A numeric vector of length 5 with the values of the abcd parameters and the initial groundwater storage
#' @param Prec A numeric vector with the values of the Precipitation (on a yearly basis)
#' @param PEV A numeric vector with the values of potential evapotranspiration
#' @param ... Additional parameters (used for compatibility reasons)
#' @return
#' A list with the following elements:
#' \itemize{
#' \item Qt: Numeric vector with the yearly discharges
#' \item SRt: Numeric vector with the surface runnoff
#' \item Wt: Numeric vector witht the available soil water
#' \item SMt: Numeric vector with the soil moisture
#' \item ETt: Numeric vector with the actual evapotranspiration
#' \item Dt: Numeric vector with the deep percolation
#' \item BFt: Numeric vector with the base flow
#' \item GFt: Numeric vector with the groundwater flow in the aquifer
#' \item GSt: Numeric vector with the groundwater storage
#' }
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family abcd_model functions
abcd.month.model <- function(par.model = c(0,0,0,0,0,0), Prec, PEV, ...){
  a <- par.model[1]
  b <- par.model[2]
  c <- par.model[3]
  d <- par.model[4]
  #
  G_1 <- par.model[5]
  S_1 <- par.model[6]
  #FC <- par.model[7]
  #
  Ep <- PEV
  number_months <- length(Prec)
  Qt <- vector('numeric', length = number_months)
  Qd <- vector('numeric', length = number_months)
  E <- vector('numeric', length = number_months)
  Wt <- vector('numeric', length = number_months)
  St <- vector('numeric', length = number_months)
  Rt <- vector('numeric', length = number_months)
  Gt <- vector('numeric', length = number_months)
  Qbt <- vector('numeric', length = number_months)
  #
  Q <- 0.0
  for(irow in 1:number_months){
    #Available soil water
    W <- Prec[irow]+S_1
    Wt[irow] <- W
    #Evapotranspiration potential
    yy <- (W+b)/(2*a)-(((W+b)/(2*a))^2-((W*b)/a))^0.5
    #Potential evapotranspiration
    E[irow] <- yy*(1-exp(-Ep[irow]/b))
    #Soil moisture
    S <- yy- E[irow]
    St[irow] <- S
    #Runoff
    Qd[irow]<- (1-c)*(W-yy)
    #GW Recharge
    R <- c*(W-yy)
    Rt[irow] <- R
    # Groundwater storage
    G <- (1/(1+d))*(R+G_1)
    Gt[irow] <- G
    # Base flow
    Qb <- d*G
    Qbt[irow] <- Qb
    # Total discharge
    Q <- Qb+Qd[irow]
    G_1 <- G
    S_1 <- S
    Qt[irow] <- Q
  }
  res <- list(Qt = Qt, Wt = Wt, SRt = Qd, SMt = St, Rt = Rt, Gt = Gt,
              Qbt = Qbt, ETt = E)
  #res <- Qt
  return(res)
}
#' @title
#' abcd.mod.year.model
#' @description
#' Function to calculate the components of the hydrological cycle using the modified abcd model
#' on a yearly basis. The modification of the original abcd model takes into account the pumping
#' rates and the depth to the aquifer used to calculate the variations in the groundwater levels
#' @param par.model A numeric vector of length 5 with the values of the abcd parameters and the initial groundwater storage
#' @param Prec A numeric vector with the values of the Precipitation (on a yearly basis)
#' @param PEV A numeric vector with the values of potential evapotranspiration
#' @param Vp A numeric vector with the values of the volumes of water extracted by pumping
#' @param ... Additional parameters (used for compatibility reasons)
#' @return
#' A list with the following elements:
#' \itemize{
#' \item Qt: Numeric vector with the yearly discharges
#' \item SRt: Numeric vector with the surface runnoff
#' \item ETt: Numeric vector with the actual evapotranspiration
#' \item Dt: Numeric vector with the deep percolation
#' \item BFt: Numeric vector with the base flow
#' \item GFt: Numeric vector with the groundwater flow in the aquifer
#' \item GSt: Numeric vector with the groundwater storage
#' }
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family abcd_model functions
abcd.mod.year.model <- function(par.model = c(0,0,0,0,0), Prec, PEV, Vp, ...){
  #
  a <- par.model[1]
  b <- par.model[2]
  c <- par.model[3]
  d <- par.model[4]
  # Initial GW storage
  G_1 <- par.model[5]
  # Initialize output vectors
  number_years <- length(Prec)
  GS <- vector('numeric', length = number_years)
  BF <- vector('numeric', length = number_years)
  Qs <- vector('numeric', length = number_years)
  GF <- vector('numeric', length = number_years)
  Vp1 <- NULL
  if(length(Vp) == 1){
    Vp1 <- vector('numeric', length = number_years)
    Vp1[1:number_years] <- Vp
  }
  else {
    Vp1 <- Vp
  }
  #
  #Surface runnof
  SR <- a*Prec
  In <- (1.0-a)*Prec
  #Evapotranspiration
  E <- b*In
  # Deep percolation
  DP <- (1.0-b)*In
  #Base flow
  BF[1] <- c*G_1
  # GW Flow
  GF[1] <- d*G_1
  for(it in 1:length(Prec)){
    if(it == 1){
      BF[it] <- c*G_1
      GF[it] <- d*G_1
      GS[it] <- (G_1-BF[it]-GF[it]-Vp1[it])+DP[it]
    }
    else {
      BF[it] <- c*GS[it-1]
      GF[it] <- d*GS[it-1]
      GS[it] <- (GS[it-1]-BF[it]-GF[it]-Vp1[it])+DP[it]
    }
    Qs[it] <- SR[it] + BF[it]
  }
  #res <- Qs
  res <- list(Qt = Qs, SRt = SR, ETt = E, Dt = DP, BFt = BF, GSt = GS)
  return(res)
}
#' @title
#' abcd.mod.month.model
#' @description
#' Function to calculate the components of the hydrological cycle using the modified abcd model
#' on a monthly basis. The modification of the original abcd model takes into account the pumping
#' rates and the depth to the aquifer used to calculate the variations in the groundwater levels
#' @param par.model A numeric vector of length 5 with the values of the abcd parameters and the initial groundwater storage
#' @param Prec A numeric vector with the values of the Precipitation (on a yearly basis)
#' @param PEV A numeric vector with the values of potential evapotranspiration
#' @param Vp A numeric vector with the values of the volumes of water extracted by pumping
#' @param ... Additional parameters (used for compatibility reasons)
#' @return
#' A list with the following elements:
#' \itemize{
#' \item Qt: Numeric vector with the yearly discharges
#' \item SRt: Numeric vector with the surface runnoff
#' \item Wt: Numeric vector witht the available soil water
#' \item SMt: Numeric vector with the soil moisture
#' \item ETt: Numeric vector with the actual evapotranspiration
#' \item Dt: Numeric vector with the deep percolation
#' \item BFt: Numeric vector with the base flow
#' \item GFt: Numeric vector with the groundwater flow in the aquifer
#' \item GSt: Numeric vector with the groundwater storage
#' }
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family abcd_model functions
abcd.mod.month.model <- function(par.model = c(0,0,0,0,0,0,0), Prec, PEV, Vp, ...){
  a <- par.model[1]
  b <- par.model[2]
  c <- par.model[3]
  d <- par.model[4]
  #
  G_1 <- par.model[5]
  S_1 <- par.model[6]
  #FC <- par.model[7]
  #
  Ep <- PEV
  number_months <- length(Prec)
  Qt <- vector('numeric', length = number_months)
  Wt <- vector('numeric', length = number_months)
  St <- vector('numeric', length = number_months)
  Rt <- vector('numeric', length = number_months)
  Gt <- vector('numeric', length = number_months)
  Qbt <- vector('numeric', length = number_months)
  Vp1 <- NULL
  if(length(Vp) == 1){
    Vp1 <- vector('numeric', length = number_months)
    Vp1[1:number_months] <- Vp
  }
  else {
    Vp1 <- Vp
  }
  #
  Q <- 0.0
  for(irow in 1:number_months){
    #Available soil water
    W <- Prec[irow]+S_1
    Wt[irow] <- W
    #Evapotranspiration potential
    yy <- (W+b)/(2*a)-(((W+b)/(2*a))^2-((W*b)/a))^0.5
    #Potential evapotranspiration
    E <- yy*(1-exp(-Ep[irow]/b))
    #Soil moisture
    S <- yy- E
    St[irow] <- S
    #Runoff
    Qd <- (1-c)*(W-yy)
    #GW Recharge
    R <- c*(W-yy)
    Rt[irow] <- R
    # Groundwater storage
    G <- (1/(1+d))*(R+G_1)
    Gt[irow] <- G-Vp1[irow]
    # Base flow
    Qb <- d*G
    Qbt[irow] <- Qb
    # Total discharge
    Q <- Qb+Qd
    G_1 <- G
    S_1 <- S
    Qt[irow] <- Q
  }
  res <- list(Qt = Qt, Wt = Wt, SRt = Qd, SMt = St, Rt = Rt, Gt = Gt,
              Qbt = Qbt, ETt = E)
  #res <- Qt
  return(res)
}
#' @title
#' sum_squared_residuals
#' @description
#' Function to calculate the sum of squared residuals between a vector of measured values and other
#' with the calculated values using a model.
#' @param measured A numeric vector with the measured values
#' @param calculated A numeric vector with the calculated values
#' @param ... Additional parameters
#' @return
#' A numeric value with the sum of squared residuals.
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
sum_squared_residuals <- function(measured, calculated, ...){
  #return(sum((measured-calculated)^2))
  return(sum((measured-calculated)^2))
}
#' @title
#' mean_absolute_deviation
#' @description
#' Function to calculates the mean absolute deviation between a vector with measured values and
#' other vector with calculated values using a mathematical model.
#' @param measured A numeric vector with the measured values
#' @param calculated A numeric vector with the calculated values
#' @param ... Additional parameters
#' @return
#' A numeric value with the mean absolute deviation.
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
mean_absolute_deviation <- function(measured, calculated, ...){
  return(mean(abs(calculated-measured)))
}
#' @title
#' max_absolute_deviation
#' @description
#' Function to calculates the maximum absolute deviation between a vector with measured values and
#' other vector with calculated values using a mathematical model.
#' @param measured A numeric vector with the measured values
#' @param calculated A numeric vector with the calculated values
#' @param ... Additional parameters
#' @return
#' A numeric value with the maximum absolute deviation.
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
max_absolute_deviation <- function(measured, calculated, ...){
  return(max(abs(calculated-measured)))
}
#' @title
#' schultz_criteria
#' @description
#' Function to calculates the schultz criteria between a vector with measured values and
#' other vector with calculated values using a mathematical model. This criteria applies only
#' to dicharge data.
#' @param measured A numeric vector with the measured values
#' @param calculated A numeric vector with the calculated values
#' @param ... Additional parameters
#' @return
#' A numeric value with the schultz criteria.
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
schultz_criteria <- function(measured, calculated, ...){
  num <- sum(abs(calculated-measured)*measured)
  den <- length(calculated)*(max(measured)^2)
  return(200*num/den)
}
#' @title
#' nash_sutcliffe
#' @description
#' Function to calculates the Nash-Sutcliffe criteria between a vector with measured values and
#' other vector with calculated values using a mathematical model. This criteria applies only
#' to dicharge data.
#' @param measured A numeric vector with the measured values
#' @param calculated A numeric vector with the calculated values
#' @param ... Additional parameters
#' @return
#' A numeric value with the  Nash-Sutcliffe criteria.
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
nash_sutcliffe <- function(measured, calculated, ...){
  num <- sum((calculated-measured)^2)
  den <- sum((measured-mean(measured))^2)
  return(1.0-(num/den))
}
#' @title
#' log_nash_sutcliffe
#' @description
#' Function to calculates the logarithmic Nash-Sutcliffe criteria between a vector with measured values and
#' other vector with calculated values using a mathematical model. This criteria applies only
#' to dicharge data.
#' @param measured A numeric vector with the measured values
#' @param calculated A numeric vector with the calculated values
#' @param ... Additional parameters
#' @return
#' A numeric value with the logarithmic Nash-Sutcliffe criteria.
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
log_nash_sutcliffe <- function(measured, calculated, ...){
  num <- sum((log(calculated)-log(measured))^2)
  den <- sum((log(measured)-mean(log(measured)))^2)
  return(1.0-(num/den))
}
#' @title
#' mass_balance_error
#' @description
#' Function to calculates the mass balance error between a vector with measured values and
#' other vector with calculated values using a mathematical model.
#' @param measured A numeric vector with the measured values
#' @param calculated A numeric vector with the calculated values
#' @param ... Additional parameters
#' @return
#' A numeric value with the mass balance error.
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
mass_balance_error <- function(measured, calculated, ...){
  return(100*sum(calculated-measured)/sum(measured))
}

#' @title
#' objective.fn
#' @description
#' Calculates the objetive function
#' @param x A numeric vector with the parameters to be estimated
#' @param fn.model A character string with the name of the model used to evaluate the parameters
#' @param fit.fn A character string with the name of the function used to calculate the difference
#' between the calculated and measured values
#' @param params A list with the arguments of the fn.model
#' @param measured A numeric vector with the measured values
#' @return
#' A numeric value of the objective function
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
objective.fn <- function(x, fn.model, params, fit.fn, measured){
 args <- params
 args$par.model <- x
 calculated <- do.call(fn.model, args)
 #print(calculated)
 args1 <- list(measured = measured, calculated = calculated$Qt)
 res <- do.call(fit.fn, args1)
 return(res)
}
#' @title
#' calibrate
#' @description
#' Function to calibrate a water balance model using different optimization methods
#' @param x A numeric vector with the initial values of the parameters
#' @param measured A numeric vector with measured values
#' @param fn.model A character string with the name of the model function
#' @param obj.fn A character string with the name of the objective function
#' @param opt.method A character string with the name of the optimization method
#' @param lower A numeric vector with the lower limits of the search area
#' @param upper A numeric vector with the upper limits of the search area
#' @param args A list with a numeric vector with the precipitation values and a numeric
#' vector with the PEV values
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#'
#' @importFrom GenSA GenSA
#' @importFrom GA ga
#' @importFrom stats optim
calibrate <- function(x, measured, fn.model, obj.fn=c('rss', 'mnad', 'mxad'),
                      opt.method = c('lbfgs', 'ga', 'sa'), lower = 1e-3,
                      upper = Inf, args){
  set.seed(12345)
  obj.fn1 <- ''
  par.res <- NULL
  res <- NULL
  if(obj.fn == 'rss'){
    obj.fn1 <- sum_squared_residuals
  }
  else if(obj.fn == 'mnad'){
    obj.fn1 <- mean_absolute_deviation
  }
  else if(obj.fn == 'mxad'){
    obj.fn1 <- max_absolute_deviation
  }
  #
  if(opt.method == 'lbfgs'){
     control.par <- list(maxit = 1000)
     par.res <- optim(x, objective.fn, fn.model = fn.model, params = args, fit.fn = obj.fn1,
                      measured = measured, method = 'L-BFGS-B', lower = lower,
                      upper = upper, control = control.par)
     res <- list(par = par.res$par, value = par.res$value, opt.obj = par.res)
  }
  else if(opt.method == 'ga'){
    par.obj.fn <- function(x, fn.model, params, fit.fn, measured){
      -1*objective.fn(x, fn.model, params, fit.fn, measured)
    }
    #control.par <- list(fnscale = -1)
    optimArgs.local <- list(method = "L-BFGS-B", potim = 0.2, pressel = 0.6)
    res.ga <- ga(type = "real-valued", fitness =  par.obj.fn, fn.model = fn.model,
                 params = args, fit.fn = obj.fn1, measured = measured,
                 min = lower, max = upper, popSize = 200, maxiter = 100, run = 50,
                 pcrossover = 0.8, pmutation = 0.1, parallel = FALSE,  optim = T,
                 optimArgs = optimArgs.local)
    res <- list( par = res.ga@solution, value = res.ga@fitnessValue, opt.obj = res.ga)
  }
  else if(opt.method == 'sa'){
    control.par <- list( verbose = TRUE, maxit = 50,
                         simple.function = T, max.time = 120)
    res.sa <- GenSA(lower = lower, upper = upper, fn = objective.fn, control = control.par,
                    fn.model = fn.model, params = args, fit.fn = obj.fn1,
                    measured = measured)
    res <- list(par = res.sa$par, value = res.sa$value, opt.obj = res.sa)
  }
  #
  return(res)
}
#' @title
#' uncertainty_quantification_boot
#' @description
#' Function to calculate the confidence intervals of the model parameters using a bootstrapping
#' approach.
#' @param measured A numeric vector with measured values
#' @param fn.model A character string with the name of the model function
#' @param obj.fn A character string with the name of the objective function
#' @param opt.method A character string with the name of the optimization method
#' @param args A list with a numeric vector with the precipitation values and a numeric
#' vector with the PEV values
#' @param level A numeric vector with the values of the quantiles associated with the
#' confidence interval to estimate
#' @param neval An integer specifying the number of model evaluation used to estimate the
#' confidence intervals
#' @param seed A random seed
#' @return
#' A list with the following entries:
#' \itemize{
#' \item model.par: A numeric vector with the values of the model parameters estimated
#' for each realization
#' \item par.ci: A numeric vector with the values of the lower and upper confidence
#' intervals of the model parameters
#' }
#' @importFrom stats quantile
#' @author
#' Oscar Garcia-Cabrejo \email{khaors@gmail.com}
#' @family calibration functions
uncertainty_quantification_boot <- function(measured, fn.model,
                                            obj.fn=c('rss', 'mnad', 'mxad'),
                                            opt.method = c('lbfgs', 'ga', 'sa'), args,
                                            level = c(0.025, 0.975), neval = 100,
                                            seed = 12345){
  # Initial parameter estimation
  res.par <- calibrate(measured, fn.model, obj.fn = obj.fn, opt.method = opt.method,
                       args)
  npar <- length(res.par$par)
  # Calculate residuals
  fn.args <- args
  fn.args$par.model <- res.par$par
  fn.res <- do.call(fn.model, fn.args)
  calculated <- fn.res$Qt
  Q.residuals <- calculated - measured
  #
  set.seed(seed)
  #
  model.par <- matrix(0.0, nrow = neval, ncol = npar)
  for(ieval in 1:neval){
    current.residuals <- sample(Q.residuals, replace = TRUE)
    currentQ <- calculated + current.residuals
    current.res.par <- calibrate(currentQ, fn.model, obj.fn = obj.fn,
                                  opt.method = opt.method, args)
    model.par[ieval,] <- current.res.par$par
  }
  #
  par.ci <- matrix(0.0, nrow = npar, ncol = length(level))
  for(ipar in 1:npar){
    par.ci[ipar,] <- quantile(model.par[,ipar], probs = level)
  }
  #
  res <- list(model.par = model.par, par.ci = par.ci)
}
