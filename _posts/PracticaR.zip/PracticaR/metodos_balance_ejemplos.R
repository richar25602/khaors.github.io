## ----setup, include=FALSE, cache=FALSE-----------------------------------
library(knitr)
## set global chunk options
opts_chunk$set(fig.align='center')
opts_chunk$set(tidy=TRUE)
## set code/output width
options(width=55)
## set number of digits
options(digits=3)
# Load pracma package
library(pracma)
#
library(GA)
#
library(GenSA)

## ----load_gwbudget, echo=TRUE--------------------------------------------
source('GWBudget.R')

## ----load_baseflow_data,ech=TRUE-----------------------------------------
Q <- read.table('CaudalMorron.dat', h = F)
Q <- Q$V1
tt <- seq(1, 228, 1)

## ----plot_discharge_baseflow,fig.height=3,fig.width=6,fig.align='center'----
plot(tt,Q, type = 'l', xlab = 'Mes', 
     ylab = 'Caudal[mm]', 
     main = 'Estacion Morron, Cauca, Colombia')

## ----morron_bf,echo=TRUE-------------------------------------------------
morron_bf_graphical <- baseflow_graphical1(Q)
morron_bf_nathan <- nathan_filter(Q, 0.925)
morron_bf_chapman <- chapman_filter(Q, 0.925)
morron_bf_eckhardt <- eckhardt_filter(Q, 0.8, 0.7)

## ----plot_discharge_baseflow_graf,fig.height=3,fig.width=6,fig.align='center'----
plot(tt,Q, type = 'l', xlab = 'Mes', 
     ylab = 'Caudal[mm]', 
     main = 'Est. Morron, Cauca, Col. - Flujo Base Grafico')
lines(morron_bf_graphical$Qbf, col = 'red')

## ----plot_discharge_baseflow_nathan,fig.height=3,fig.width=6,fig.align='center'----
plot(tt,Q, type = 'l', xlab = 'Mes', 
     ylab = 'Caudal[mm]', 
     main = 'Est. Morron, Cauca, Col. - Flujo Base Filtro Nathan')
lines(morron_bf_nathan, col = 'blue')

## ----plot_discharge_baseflow_chapman,fig.height=3,fig.width=6,fig.align='center'----
plot(tt,Q, type = 'l', xlab = 'Mes', 
     ylab = 'Caudal[mm]', 
     main = 'Est. Morron, Cauca, Col. - Flujo Base Filtro Chapman')
lines(morron_bf_chapman, col = 'green')

## ----plot_discharge_baseflow_eckhardt,fig.height=3,fig.width=6,fig.align='center'----
plot(tt,Q, type = 'l', xlab = 'Mes', 
     ylab = 'Caudal[mm]', 
     main = 'Est. Morron, Cauca, Col. - Flujo Base Filtro Eckhardt')
lines(morron_bf_eckhardt, col = 'orange')

## ----plot_discharge_baseflow_all,fig.height=4.5,fig.width=7,fig.align='center'----
plot(tt,Q, type = 'l', xlab = 'Mes', 
     ylab = 'Caudal[mm]', 
     main = 'Est. Morron, Cauca, Col. - Flujo Base Comparacion', cex.main = 0.7, 
     cex.lab = 0.7, cex.axis = 0.7, lwd = 1)
lines(morron_bf_nathan, col = 'blue')
lines(morron_bf_chapman, col = 'green')
lines(morron_bf_eckhardt, col = 'orange')
legend('topright', legend = c('Q.Medidos','Nathan','Chapman','Eckhardt'), 
       lty = c(1,1,1,1), col = c('black','blue','green','orange'), 
       y.intersp = 0.7, cex = 0.7)

## ----load_paez,echo=TRUE-------------------------------------------------
paez <- read.table('paez_anual.txt', h = F)
tt.paez <- paez$V1
P.paez <- paez$V2
Q.paez <- paez$V3

## ----plot_paez,fig.height=6,fig.height=6---------------------------------
par0 <- par(no.readonly = TRUE)
par(mfrow = c(2,1))
plot(tt.paez, P.paez, type = 'l', xlab ='A�o', ylab = 'Prec[mm]',
     main = 'Cuenca Rio Paez, Estacion PM1')
plot(tt.paez, Q.paez, type = 'l', xlab ='A�o', ylab = 'Caudal[mm]',
     main = 'Cuenca Rio Paez, Estacion Q1')
par(par0)

## ----paez_parameters,echo=TRUE-------------------------------------------
x <- c(.5, .5, .5, .1, 300)
control.par <- list(maxit = 1000)
par.paez.opt.rss <- calibrate(x, Q.paez, abcd.year.model, 'rss',
                                  opt.method = 'lbfgs', 
                                  lower = rep(1e-3, 5), 
                                  upper = c(1, 1, 1, 1, 1500), 
                                  list(Prec = P.paez))

## ----paez_evaluation,echo=TRUE-------------------------------------------
paez.sim <- abcd.year.model(par.paez.opt.rss$par, Prec = P.paez)

## ----paez_comparison,fig.height=4,fig.width=6,fig.align='center'---------
plot(tt.paez, Q.paez, type = 'l', xlab = 'a�o', ylab = 'Caudal[mm]', 
     main = 'Cuenca Rio Paez, Estacion Q1')
lines(tt.paez, paez.sim$Qt, col = 'red')
legend('topright', legend = c('Q.Medidos','Q.Simulados'), 
       lty = c(1,1), col = c('black','red'), 
       y.intersp = 0.7, cex = 0.7)

## ----paez_corr,fig.height=4,fig.width=4,fig.align='center'---------------
plot(Q.paez, paez.sim$Qt, type = 'p', xlab = 'Caudales Medidos', 
     ylab = 'Caudales Simulados', 
     main = 'Cuenca Rio Paez: Comparaci�n Caudales',
     ylim = c(100,250),  cex.main = 0.7, cex.lab = 0.7, 
     cex.axis = 0.7)
lines(c(100,250), c(100,250), col='red')

## ----paez_components1,fig.height=6,fig.width=6,fig.align='center'--------
par0 <- par(no.readonly = TRUE)
par(mfrow=c(2,2))
plot(tt.paez, P.paez, type = 'l', xlab = 'a�o', ylab = 'Prec[mm]', 
     main = 'Precipitaci�n', col = 'red')
plot(tt.paez, paez.sim$SRt, type = 'l', xlab = 'A�o', 
     ylab = 'Esc.[mm]', main = 'Escorrent�a')
plot(tt.paez, paez.sim$ETt, type = 'l', xlab = 'A�o', 
     ylab = 'EVT[mm]', main = 'Evapotranspiraci�n')
plot(tt.paez, paez.sim$Dt, type = 'l', xlab = 'A�o', 
     ylab = 'R[mm]', main = 'Recarga')
par(par0)

## ----paez_components2s,fig.height=6,fig.width=6,fig.align='center'-------
par0 <- par(no.readonly = TRUE)
par(mfrow=c(2,2))
plot(tt.paez, P.paez, type = 'l', xlab = 'a�o', ylab = 'Prec[mm]', 
     main = 'Precipitaci�n', col = 'red')
plot(tt.paez, paez.sim$BFt, type = 'l', xlab = 'A�o', 
     ylab = 'FB[mm]', main = 'Flujo Base')
plot(tt.paez, paez.sim$GFt, type = 'l', xlab = 'A�o', 
     ylab = 'FG[mm]', main = 'Flujo Regional Subterr�neo')
plot(tt.paez, paez.sim$GSt, type = 'l', xlab = 'A�o', 
     ylab = 'GS[mm]', main = 'Almacenamiento Subterr�neo')
par(par0)

## ----load_thomas_month,echo=TRUE-----------------------------------------
D <- read.table('PM1data.out', h=F)
tt.m <- D[,1]
P.m <- D[,2]
EVT.m <- D[,5]
Q.m <- D[,3]

## ----thomas_month_plot, fig.height=6,fig.width=6,fig.align='center'------
par0 <- par(no.readonly = TRUE)
par(mfrow=c(3,1))
plot(tt.m, P.m, type ='l', xlab = 'Mes', ylab = 'P[mm]', 
     main = 'Precipitaci�n: Estaci�n PM1')
plot(tt.m, Q.m, type='l', xlab = 'Mes', ylab = 'Q[mm]', 
     main = 'Caudal Estaci�n Morr�n' )
plot(tt.m, EVT.m, type='l', xlab = 'Mes', ylab = 'EVT[mm]', 
     main = 'Evapotranspiraci�n Potencial Cuenca X' )
par(par0)

## ----thomas_month_calibrate,echo=TRUE------------------------------------
x <- c(.5, 100, .5, .1, 100, 100)
control.par <- list(maxit = 1000)
par.m.opt.rss <- calibrate(x, Q.m, abcd.month.model, 'rss',
                                  opt.method = 'lbfgs', 
                                  lower = rep(1e-3, 6), 
                                  upper = c(1, 1000, 1, 1, 1000, 1500), 
                                  list(Prec = P.m, PEV = EVT.m))

## ----m_evaluation,echo=TRUE----------------------------------------------
m.sim <- abcd.month.model(par.m.opt.rss$par, Prec = P.m, PEV = EVT.m)

## ----m_comparison,fig.height=4,fig.width=6,fig.align='center'------------
plot(tt.m, Q.m, type = 'l', xlab = 'Mes', ylab = 'Caudal[mm]', 
     main = 'Caudal Estacion Morr�n, Cauca, Colombia')
lines(tt.m, m.sim$Qt, col = 'red')
legend('topright', legend = c('Q.Medidos','Q.Simulados'), 
       lty = c(1,1), col = c('black','red'), 
       y.intersp = 0.7, cex = 0.7)

## ----m_corr,fig.height=4,fig.width=4,fig.align='center'------------------
plot(Q.m, m.sim$Qt, type = 'p', xlab = 'Caudales Medidos', 
     ylab = 'Caudales Simulados', 
     main = 'Comparaci�n Caudales',
     ylim = c(20,250),  cex.main = 0.7, cex.lab = 0.7, 
     cex.axis = 0.7)
lines(c(20,250), c(20,250), col='red')

## ----m_components1,fig.height=6,fig.width=6,fig.align='center'-----------
par0 <- par(no.readonly = TRUE)
par(mfrow=c(2,2))
plot(tt.m, P.m, type = 'l', xlab = 'Mes', ylab = 'Prec[mm]', 
     main = 'Precipitaci�n', col = 'red')
plot(tt.m, m.sim$SRt, type = 'l', xlab = 'Mes', 
     ylab = 'Esc.[mm]', main = 'Escorrent�a')
plot(tt.m, m.sim$SMt, type = 'l', xlab = 'Mes', 
     ylab = 'SM[mm]', main = 'Humedad del Suelo')
plot(tt.m, m.sim$ETt, type = 'l', xlab = 'Mes', 
     ylab = 'EVT[mm]', main = 'Evapotranspiraci�n')
par(par0)

## ----m_components2s,fig.height=6,fig.width=6,fig.align='center'----------
par0 <- par(no.readonly = TRUE)
par(mfrow=c(2,2))
plot(tt.m, P.m, type = 'l', xlab = 'Mes', ylab = 'Prec[mm]', 
     main = 'Precipitaci�n', col = 'red')
plot(tt.m, m.sim$Rt, type = 'l', xlab = 'Mes', 
     ylab = 'R[mm]', main = 'Recarga')
plot(tt.m, m.sim$Qbt, type = 'l', xlab = 'Mes', 
     ylab = 'FB[mm]', main = 'Flujo Base')
plot(tt.m, m.sim$Gt, type = 'l', xlab = 'Mes', 
     ylab = 'GS[mm]', main = 'Almacenamiento Subterr�neo')
par(par0)

